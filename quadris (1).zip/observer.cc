//
//  observer.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include "observer.h"
