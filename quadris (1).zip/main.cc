//
//  main.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-16.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include <iostream>
#include <string>
#include <memory>
#include <cstdlib>
#include "interpreter.h"
#include "block.h"
#include "board.h"
#include <cstdlib>

using namespace std;

int main(int argc, const char * argv[]) {
    Information info;
    
    // Sets initial pottential command line inputes to
    // default state
    
    bool onlyText = true;
    int setSeed = 0;
    int setLevel = 0;
    string initialFile = "sequence.txt";
    
    // Reads from command line and initializes pottential
    // inputs above to new adjusted values
    
    for (int i = 1; i < argc; i++) {
        string cmp = argv[i];
        
        if (cmp == "-text") {
            onlyText = true;
            if (onlyText) onlyText = true;
            
        } else if (cmp == "-seed") {
            i++;
            setSeed = stoi(argv[i]);
            
        } else if (cmp == "-scriptfile") {
            i++;
            initialFile = argv[i];
            
        } else if (cmp == "-startlevel") {
            i++;
            setLevel = stoi(argv[i]);
            
            // Sets acceptable level if user command
            // is not valid
            
            if (setLevel > 4) {
                setLevel = 4;
            }
            
            if (setLevel < 0) {
                setLevel = 0;
            }
            
        }
    }
    
    // Initializes info and Board class
    srand(setSeed);
    info.setLevel(setLevel);
    info.setFileInUse(initialFile);
    Board aBoard = Board(&info);
    
    // Starts game in most basic state
    aBoard.startGame();
    
    // Runs loop so users can play game
    Interpreter interpret(&info, &aBoard);
    interpret.run(cin);
}

