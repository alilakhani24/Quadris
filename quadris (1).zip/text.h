//
//  text.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#ifndef text_h
#define text_h

#include "observer.h"

class Text: public Observer {
public:
    // Notifies the text observer in order to get the state of the board and re-display to board
    void notify(Subject &subject) override;
};


#endif /* text_hpp */
