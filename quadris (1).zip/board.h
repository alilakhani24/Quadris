//
//  board.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#ifndef board_h
#define board_h

#include <iostream>
#include <fstream>
#include <memory>
#include <vector>
#include <tuple>
#include "subject.h"
#include "block.h"
#include "information.h"
#include <cstdlib>

extern int countRead;
extern bool gameOver;
extern int movesWithoutClear;
extern bool execute;
extern bool nonRandom;
extern int countReadNonRan;
extern bool sequenceUsed;

class Board: public Subject {
    Information *info;
    std::vector<std::vector<std::shared_ptr<Block>>> board;
    std::shared_ptr<Block> currentBlock;
    std::shared_ptr<Block> nextBlock;
    std::vector<std::tuple<int, int>> vectorCurrentBlock;
    bool possibleDown, possibleRight, possibleLeft, possibleClock, possibleCounter;
    
    std::shared_ptr<Observer> textOutput;
    
    bool isDownValid();
    bool isRightValid();
    bool isLeftValid();
    bool isClockRotateValid();
    bool isCounterRotateValid();
    bool blockExists(std::tuple<int, int> coordinate);
    bool putChar(std::tuple<int, int> coordinate, char c);
    void generateNextBlock();
    bool isBottomLineFull();

public:
    // Initializes board with argument info
    Board(Information *info);
    // Gets current board that was initialized
    std::vector<std::vector<std::shared_ptr<Block>>> getBoard() override;
    // Gets the current block being played in the game
    std::shared_ptr<Block> getCurrentBlock() override;
    // Gets the next block that will be played in the game
    std::shared_ptr<Block> getNextBlock() override;
    // Gets the coordinates of the current block in the game
    std::vector<std::tuple<int, int>> vectorGetCurrentBlock() override;
    // Gets the info that is associated with the board
    Information *getInfo() override;
    
    // Sets next block to be played on the board
    void setNextBlock(shared_ptr<Block> newNextBlock);
    // Sets current block to be played on the board
    void setCurrentBlock(shared_ptr<Block> newCurrBlock);
    // Sets the grid to be displayed on the board
    void setBoard(std::vector<std::vector<std::shared_ptr<Block>>> grid);
    // Sets the boolean values refereing to if a block can be moved
    // on the board after each move
    void setBool();
    // Starts the game taking in the first two blocks from initial file
    void startGame();
    // Calls clearRow depending on how many rows should be cleared and
    // sets score
    void clearRow();
    // Clears the rows of the grid if it is full and returns score
    // associated with blocks cleared
    int runClearRow();
    // Outputs true if the inputed block is the last block of its type
    // on the Grid
    bool lastBlock(std::shared_ptr<Block> currentBlock);
    // Outputs a char related to the block that should be displayed next
    char blockSelector(int level);
    // Sets the "star" block in the middle of the board in levels 3 and 4
    void setStarBlock();
    // Drops the current block to the bottom by recursively calling down
    void dropBlock();
    // Moves the current block down depending on the times entered
    void moveBlockDown(int times);
    // Moves the current block right depending on the times entered
    void moveBlockRight(int times);
    // Moves the current block left depending on the times entered
    void moveBlockLeft(int times);
    // Rotates the current block clockwise depending on the
    // times entered
    void rotateBlockClock(int times);
    // Rotates the current block counterclockwise depending on the
    // times entered
    void rotateBlockCounter(int times);
    // Clears the grid entirely
    void clearGrid();
};


#endif /* board_hpp */
