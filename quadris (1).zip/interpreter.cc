//
//  interpreter.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-16.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include "interpreter.h"
#include "information.h"
using namespace std;
/*
 string findMultiplier(string str, int &num) {
 string counter = "";
 for (int i = 0; i < str.length(); i++) {
 if (isdigit(str[i])) {
 counter.append(&str[i]);
 //   cout << counter << endl;
 num++;
 } else {
 break;
 }
 }
 return counter;
 }
 */

Interpreter::Interpreter(Information *info, Board *aboard) : info{info}, aboard{aboard} {}

int findMultiplier(string str) {
    istringstream ss(str);
    int n;
    if (ss >> n) {
        return n;
    } else {
        return 1;
    }
}


void Interpreter::run(istream &in) {
    
    
    string LEFT = "left";
    string RIGHT = "right";
    string DOWN = "down";
    string CLOCKWISE = "clockwise";
    string COUNTERCLOCKWISE = "counterclockwise";
    string DROP = "drop";
    string LEVELUP = "levelup";
    string LEVELDOWN = "leveldown";
    string NORANDOM = "norandom";
    string RANDOM = "random";
    string SEQUENCE = "sequence";
    string RESTART = "restart";
    string HINT = "hint";
    string I = "I";
    string J = "J";
    string L = "L";
    string O = "O";
    string S = "S";
    string Z = "Z";
    string T = "T";
    
    string s;
    int multiplier = 0;
    
    
    while (in >> s) {
        
        istringstream ss(s);
        int n;
        
        if (ss >> n) {
            // cout << n << endl;
            // if ...
            // call with command and board      interpret->run()
        }
        
        multiplier = findMultiplier(s);
        double start = s.find_first_not_of( "0123456789" );
        string subString = s.substr(start);
        
        // determine which command to execute
        
        if (gameOver) {
            if ((RESTART.find(subString)) == 0) {
            this->restart();
            } else {
                continue;
            }
        }
        
        
        if ((subString.length() < 1) || (subString == "c") || (subString == "l") || (subString == "le")
            || (subString == "lev") || (subString == "leve") || (subString == "level") || (subString == "d")
            || (subString == "r")) {
            cout << "Please enter a command with more characters" << endl;
        } else if  ((LEFT.find(subString)) == 0) {
            this->left(multiplier);
        
                aboard->notify();

            

        
            
        } else if ((RIGHT.find(subString)) == 0) {
            this->right(multiplier);
                aboard->notify();

            
        
            
        } else if ((DOWN.find(subString)) == 0) {
            this->down(multiplier);
 
                aboard->notify();

            
        
            
        } else if ((CLOCKWISE.find(subString)) == 0) {
            this->clockwise(multiplier);
  
                aboard->notify();

            
        
            
        } else if ((COUNTERCLOCKWISE.find(subString)) == 0) {
            this->counterclockwise(multiplier);
     
                aboard->notify();
       
            
        
        } else if ((DROP.find(subString)) == 0) {
           this->drop();
           this->aboard->clearRow();
            if (gameOver) {
                 cout << "GAME OVER :(" << endl;
            }
            
        } else if ((LEVELUP.find(subString)) == 0) {
            for (int i = 0; i < multiplier; i++) {
                this->levelup();
            }
            aboard->notify();
        } else if ((LEVELDOWN.find(subString)) == 0) {
            for (int i = 0; i < multiplier; i++) {
                this->leveldown();
            }
            aboard->notify();
        } else if ((NORANDOM.find(subString)) == 0) {
            string fileNAME;
            in >> fileNAME;
            this->norandom(fileNAME);
            //  cout << multiplier << " times" << endl;
            
        } else if ((RANDOM.find(subString)) == 0) {
            this->random();
        //    cout << multiplier << " times" << endl;
            
        } else if ((SEQUENCE.find(subString)) == 0) {
            sequenceUsed = true;
            string fileNAME;
            in >> fileNAME;
            this->sequence(fileNAME);
            sequenceUsed = false;
    
        } else if ((RESTART.find(subString)) == 0) {
            this->restart();
            
        } else if ((HINT.find(subString)) == 0) {
            this->hint();
            cout << multiplier << " times" << endl;
        } else if ((I.find(subString)) == 0) {
            this->I();
           // aboard->notify();
            if (!sequenceUsed) {
                this->run(cin);
            }
        } else if ((J.find(subString)) == 0) {
            this->J();
         //   aboard->notify();
            if (!sequenceUsed) {
                this->run(cin);
            }
        } else if ((L.find(subString)) == 0) {
            this->L();
          //  aboard->notify();
            if (!sequenceUsed) {
                this->run(cin);
            }
        } else if ((S.find(subString)) == 0) {
            this->S();
          //  aboard->notify();
            if (!sequenceUsed) {
                this->run(cin);
            }
        } else if ((T.find(subString)) == 0) {
            this->T();
          //  aboard->notify();
            if (!sequenceUsed) {
                this->run(cin);
            }
        } else if ((O.find(subString)) == 0) {
            this->O();
           // aboard->notify();
            if (!sequenceUsed) {
                this->run(cin);
            }
        } else if ((Z.find(subString)) == 0) {
            this->Z();
           // aboard->notify();
            if (!sequenceUsed) {
            this->run(cin);
            }
        } else {
            cout << "Please enter a valid command" << endl;
        }
    }
}

void Interpreter::left(int times) {
    aboard->moveBlockLeft(times);
    if (aboard->getCurrentBlock()->isHeavy()) {
        aboard->moveBlockDown(times);
    }
}

void Interpreter::right(int times) {
    aboard->moveBlockRight(times);    
    if (aboard->getCurrentBlock()->isHeavy()) {
        aboard->moveBlockDown(times);
    }
   
    
}

void Interpreter::down(int times) {
    aboard->moveBlockDown(times);
    if (aboard->getCurrentBlock()->isHeavy()) {
        aboard->moveBlockDown(times);
    }
   
}

void Interpreter::clockwise(int times) {
    aboard->rotateBlockClock(times);
    if (aboard->getCurrentBlock()->isHeavy()) {
        aboard->moveBlockDown(times);
    }

}

void Interpreter::counterclockwise(int times) {
    aboard->rotateBlockCounter(times);
    if (aboard->getCurrentBlock()->isHeavy()) {
        aboard->moveBlockDown(times);
    }

}

void Interpreter::drop() {
    aboard->dropBlock();
    movesWithoutClear++;
    if ((aboard->getInfo()->getLevel() == 4) && (movesWithoutClear > 0)
        && (movesWithoutClear % 5 == 0)) {
        aboard->setStarBlock();
    }
}

void Interpreter::levelup() {
    if (info->getLevel() < 4) {
        aboard->getInfo()->Levelup();
    }
 //   cout << info->getLevel() << endl;
}

void Interpreter::leveldown() {
    if (info->getLevel() > 0) {
        aboard->getInfo()->Leveldown();
    }
  //  cout << info->getLevel() << endl;
}

void Interpreter::random() {
    if ((aboard->getInfo()->getLevel()) > 2) {
    nonRandom = false;
    }
    aboard->notify();
}

void Interpreter::norandom(string name) {
    if ((aboard->getInfo()->getLevel()) > 2) {
    nonRandom = true;
        aboard->getInfo()->setNonRanFile(name);
    }
    aboard->notify();
}

void Interpreter::sequence(string name) {
    ifstream iFile;
    iFile.open(name);
    this->run(iFile);
    iFile.close();
    this->run(cin);
}

void Interpreter::restart() {
    aboard->startGame();
}

void Interpreter::hint() {
    cout << "hint" << " ";
}

void Interpreter::I() {
    shared_ptr<Block> block = make_shared<Block>(info, 'I');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

void Interpreter::J() {
    shared_ptr<Block> block = make_shared<Block>(info, 'J');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

void Interpreter::L() {
    shared_ptr<Block> block = make_shared<Block>(info, 'L');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

void Interpreter::O() {
    shared_ptr<Block> block = make_shared<Block>(info, 'O');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

void Interpreter::S() {
    shared_ptr<Block> block = make_shared<Block>(info, 'S');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

void Interpreter::Z() {
    shared_ptr<Block> block = make_shared<Block>(info, 'Z');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

void Interpreter::T() {
    shared_ptr<Block> block = make_shared<Block>(info, 'T');
    aboard->setCurrentBlock(block);
    aboard->notify();
}

/*
 Interpreter::~Interpreter() {
 delet
 }
 */

