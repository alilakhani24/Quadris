//
//  information.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-16.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//


#ifndef information_h
#define information_h

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

class Information {
    int highScore = 0;
    int score = 0;
    int currentLevel = 0;
    int blockGenLevel = 0;
    int linesJustCleared;
    string fileInUse;
    string nonRanFile;
public:
    
    // Sets score
    void setScore(int aScore);
    // Sets Highscore
    void setHighScore(int aScore);
    // Sets level
    void setLevel(int x);
    // Increases level by 1
    void Levelup();
    // Decreases level by 1
    void Leveldown();
    // Sets the current file used in level 0
    // to generate blocks
    void setFileInUse(string file);
    // Retrieves the current file used in level 0
    // to generate blocks
    string getFileInUse();
    // Retrieves the current Score
    int getScore();
    // Retrieves the current Highscore
    int getHighScore();
    // Retrieves the current level
    int getLevel();
    // Sets the number of lines just cleared
    void setLinesCleared(int lines);
    // Gets number of lines cleared
    int getLinesCleared();
    // Gets the level a block was generated in
    int getBlockGenLevel();
    // Sets the level a block was generated in
    void setBlockGenLevel(int lev);
    // Gets files used incase not random in level 3/4
    string getNonRanFile();
    // Sets files used incase not random in level 3/4
    void setNonRanFile(string str);
};








#endif /* information_hpp */

