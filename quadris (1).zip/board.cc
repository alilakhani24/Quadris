//
//  board.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include "board.h"
#include "text.h"
using namespace std;

// Global variables used to manipulate output based on
// state of the game.
int countRead = 0;
int countReadNonRan;
bool gameOver = false;
int movesWithoutClear = 0;
bool execute = true;
bool nonRandom = false;
bool sequenceUsed = false;

vector<vector<shared_ptr<Block>>> Board::getBoard() {
    return board;
}

shared_ptr<Block> Board::getCurrentBlock() {
    return currentBlock;
}

shared_ptr<Block> Board::getNextBlock() {
    return nextBlock;
}

vector<tuple<int, int>> Board::vectorGetCurrentBlock() {
    return vectorCurrentBlock;
}

Information *Board::getInfo() {
    return info;
}


void Board::startGame() {
    gameOver = false;
    movesWithoutClear = 0;
    countRead = 0;
    countReadNonRan = 0;
    this->getInfo()->setScore(0);
    string useFile = this->info->getFileInUse();
    
    vector<std::vector<std::shared_ptr<Block>>> grid;
    for (int i = 0; i < 18; i++) {
        vector<std::shared_ptr<Block>> wid;
        for (int j = 0; j < 11; j++) {
            wid.emplace_back(nullptr);
        }
        grid.emplace_back(wid);
    }
    
    this->setBoard(grid);
    
    shared_ptr<Block> ablock1 = make_shared<Block>(this->info, blockSelector(this->getInfo()->getLevel()));
    this->setCurrentBlock(ablock1);
    
    shared_ptr<Block> ablock2 = make_shared<Block>(this->info, blockSelector(this->getInfo()->getLevel()));
    this->setNextBlock(ablock2);
    
    this->notify();
}

void Board::clearGrid() {
    vector<std::vector<std::shared_ptr<Block>>> grid;
    for (int i = 0; i < 18; i++) {
        vector<std::shared_ptr<Block>> wid;
        for (int j = 0; j < 11; j++) {
            wid.emplace_back(nullptr);
        }
        grid.emplace_back(wid);
    }
    
    this->setBoard(grid);
}


void Board::clearRow() {
    int addScore = 0;
    bool rowFull = true;
    int pushDown = 0;
    int lastFullRow = 17;
    ++lastFullRow;
    for (int i = 17; i >= 0; i--) {
        for (int j = 0; j < 11; j++) {
            if (this->getBoard()[i][j] == nullptr) {
                rowFull = false;
            }
        }
        if (rowFull) {
            lastFullRow = i;
            pushDown++;
        }
        rowFull = true;
    }
    
    // Generates score for clearing lines
    
    if (pushDown > 0) {
        movesWithoutClear = 0;
        addScore = (this->getInfo()->getLevel() + pushDown)
        * (this->getInfo()->getLevel() + pushDown);
    }
    
    // Adds score for removing complete blocks
    for (int i = 0; i < pushDown; i++) {
        addScore += runClearRow();
    }
    
    // Adds additional score to current score and sets
    // Highscore if needed
    
    addScore += this->getInfo()->getScore();
    this->getInfo()->setScore(addScore);
    if (this->getInfo()->getScore() > this->getInfo()->getHighScore()) {
        this->getInfo()->setHighScore(this->getInfo()->getScore());
    }
    
    // Notifies only if at least 1 line was cleared
    if (pushDown > 0) {
        notify();
    }
    
}

int Board::runClearRow() {
    int addScore = 0;
    bool rowFull = true;
    int row = 17;
    for (int i = 17; i >= 0; i--) {
        for (int j = 0; j < 11; j++) {
            if (this->getBoard()[i][j] == nullptr) {
                rowFull = false;
            }
        }
        if (rowFull) {
            row = i;
            break;
        } else {
            rowFull = true;
        }
    }
    for (int j = 0; j < 11; j++) {
        if ((lastBlock(this->board[row][j])) && ((this->getBoard()[row][j]) != nullptr))  {
            addScore += ((((this->board[row][j])->getLevelCreated()) + 1) *
                         (((this->board[row][j])->getLevelCreated()) + 1));
            (this->board[row][j]) = nullptr;
        } else {
            (this->board[row][j]) = nullptr;
        }
    }
    
    for (int i = row - 1; i >= 0; i--) {
        for (int j = 0; j < 11; j++) {
            (this->board[i + 1][j]) = this->board[i][j];
        }
    }
    
    for (int j = 0; j < 11; j++) {
        (this->board[0][j]) = nullptr;
    }
    
    cout <<addScore<<endl;
    return addScore;
}


// Goes through ever cell in grid to see if the entered block
// is the last of its kind on the grid

bool Board::lastBlock(std::shared_ptr<Block> currentBlock) {
    int last = 0;
    for (int i = 17; i >= 0; i--) {
        for (int j = 0; j < 11; j++) {
            if (this->board[i][j] == currentBlock) {
                last++;
            }
        }
    }
    if (last == 1) {
        return true;
    } else {
        return false;
    }
}

void Board::setBool() {
    int minLeft = 100;
    int maxRight = 0;
    int maxDown= 0;
    vector<tuple<int, int>> tempCurrent = this->vectorGetCurrentBlock();
    for (int i = 0; i < 4; i++) {
        if (get<0>(tempCurrent[i]) < minLeft) {
            minLeft = get<0>(tempCurrent[i]);
        }
        if (get<0>(tempCurrent[i]) > maxRight) {
            maxRight = get<0>(tempCurrent[i]);
        }
        if (get<1>(tempCurrent[i]) > maxDown) {
            maxDown = get<1>(tempCurrent[i]);
        }
    }
    if (minLeft == 0) {
        this->possibleLeft = false;
        this->possibleRight = true;
    } else {
        this->possibleLeft = true;
        this->possibleRight = true;
    }
    if (maxRight == 10) {
        this->possibleLeft = true;
        this->possibleRight = false;
    }
    if (maxDown == 17) {
        this->possibleDown = false;
    }
}

Board::Board(Information *info) {
    this->info = info;
    textOutput = make_shared<Text>();
    addObserver(textOutput);
}

void Board::setNextBlock(shared_ptr<Block> newNextBlock) {
    nextBlock =  newNextBlock;
}

void Board::setCurrentBlock(shared_ptr<Block> newCurrBlock) {
    this->currentBlock = newCurrBlock;
    this->vectorCurrentBlock = newCurrBlock->getConfig();
    
    for (int i = 0; i < 4; i++) {
        get<1>(this->vectorCurrentBlock[i]) += 3;
    }
    
    this->possibleDown = true;
    this->possibleRight = true;
    this->possibleLeft = false;
    this->possibleClock = true;
    this->possibleCounter = true;
}

void Board::setBoard(std::vector<std::vector<std::shared_ptr<Block>>> grid) {
    this->board = grid;
}

bool Board::isDownValid() {
    bool canDown = true;
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->vectorGetCurrentBlock()[i];
        if (this->board[(get<1>(coord)) + 1][get<0>(coord)] != nullptr) {
            canDown = false;
        }
    }
    return canDown;
}

bool Board::isRightValid() {
    bool canRight = true;
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->vectorGetCurrentBlock()[i];
        if (this->board[get<1>(coord)][(get<0>(coord)) + 1] != nullptr) {
            canRight = false;
        }
    }
    return canRight;
}

bool Board::isLeftValid() {
    bool canLeft = true;
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->vectorGetCurrentBlock()[i];
        if (this->board[get<1>(coord)][(get<0>(coord)) - 1] != nullptr) {
            canLeft = false;
        }
    }
    return canLeft;
}


void Board::moveBlockDown(int times) {
    for (int i = 0; i < times; i++) {
        if (possibleDown) {
            if (isDownValid()) {
                for (int i = 0; i < 4; i++) {
                    get<1>(this->vectorCurrentBlock[i]) += 1;
                }
            }
            this->setBool();
        } else {
            this->setBool();
            break;
        }
    }
}


void Board::moveBlockRight(int times) {
    for (int i = 0; i < times; i++) {
        if (possibleRight) {
            if (isRightValid()) {
                for (int i = 0; i < 4; i++) {
                    get<0>(this->vectorCurrentBlock[i]) += 1;
                }
            }
        } else {
            this->setBool();
            break;
        }
        this->setBool();
    }
}

void Board::moveBlockLeft(int times) {
    for (int i = 0; i < times; i++) {
        if (possibleLeft) {
            if (isLeftValid()) {
                for (int i = 0; i < 4; i++) {
                    get<0>(this->vectorCurrentBlock[i]) -= 1;
                }
            }
        } else {
            this->setBool();
            break;
        }
        this->setBool();
    }
}

// Both rotates initialy rotate block on its initial
// position and then display after translating it based
// its current position on the board

bool Board::isCounterRotateValid() {
    int pivotX = 100; //value of pivotX doesnt matter at first
    int pivotY = 0; //value of pivotY doesnt matter at first
    
    int checkX = 100; //value of checkX doesnt matter at first
    int checkY = 0; //value of checkY doesnt matter at first
    
    int difX;
    int difY;
    
    bool canRotate = true;
    
    
    vector<tuple<int, int>> tempCurrent = this->vectorGetCurrentBlock();
    
    for (int i = 0; i < 4; i++) {
        if (get<0>(tempCurrent[i]) < pivotX) {
            pivotX = get<0>(tempCurrent[i]);
        }
        if (get<1>(tempCurrent[i]) > pivotY) {
            pivotY = get<1>(tempCurrent[i]);
        }
    }
    
    this->currentBlock->counterRotate();
    
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
        
        for (int i = 0; i < 4; i++) {
            if (get<0>(coord) < checkX) {
                checkX = get<0>(coord);
            }
            if (get<1>(coord) > checkY) {
                checkY = get<1>(coord);
            }
        }
    }
    
    difX = pivotX - checkX;
    difY = pivotY - checkY;
    
    bool shouldRotate = true;
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
        if (!(((0 <= (get<1>(coord) + difY)) && (17 >= (get<1>(coord) + difY))) &&
              ((0 <= (get<0>(coord) + difX)) && (10 >= (get<0>(coord) + difX))))){
            shouldRotate = false;
        }
    }
    
    if (shouldRotate) {
        for (int i = 0; i < 4; i++) {
            std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
            if (this->board[get<1>(coord) + difY][get<0>(coord) + difX] != nullptr) {
                canRotate = false;
            }
        }
        
        if (canRotate) {
            for (int i = 0; i < 4; i++) {
                std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
                get<0>(coord) += difX;
                get<1>(coord) += difY;
                this->vectorCurrentBlock[i] = coord;
            }
        }
    }
    
    if (shouldRotate) {
        return canRotate;
    } else {
        this->currentBlock->clockRotate();
        return shouldRotate;
    }
}


bool Board::isClockRotateValid() {
    int pivotX = 100; //value of pivotX doesnt matter at first
    int pivotY = 0; //value of pivotY doesnt matter at first
    
    int checkX = 100; //value of checkX doesnt matter at first
    int checkY = 0; //value of checkY doesnt matter at first
    
    int difX;
    int difY;
    
    bool canRotate = true;
    
    
    vector<tuple<int, int>> tempCurrent = this->vectorGetCurrentBlock();
    
    for (int i = 0; i < 4; i++) {
        if (get<0>(tempCurrent[i]) < pivotX) {
            pivotX = get<0>(tempCurrent[i]);
        }
        if (get<1>(tempCurrent[i]) > pivotY) {
            pivotY = get<1>(tempCurrent[i]);
        }
    }
    
    this->currentBlock->clockRotate();
    
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
        
        for (int i = 0; i < 4; i++) {
            if (get<0>(coord) < checkX) {
                checkX = get<0>(coord);
            }
            if (get<1>(coord) > checkY) {
                checkY = get<1>(coord);
            }
        }
    }
    
    difX = pivotX - checkX;
    difY = pivotY - checkY;
    
    bool shouldRotate = true;
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
        if (!(((0 <= (get<1>(coord) + difY)) && (17 >= (get<1>(coord) + difY))) &&
              ((0 <= (get<0>(coord) + difX)) && (10 >= (get<0>(coord) + difX))))){
            shouldRotate = false;
        }
    }
    
    if (shouldRotate) {
        for (int i = 0; i < 4; i++) {
            std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
            if (this->board[get<1>(coord) + difY][get<0>(coord) + difX] != nullptr) {
                canRotate = false;
            }
        }
        
        if (canRotate) {
            for (int i = 0; i < 4; i++) {
                std::tuple<int, int> coord = this->currentBlock->getConfig()[i];
                get<0>(coord) += difX;
                get<1>(coord) += difY;
                this->vectorCurrentBlock[i] = coord;
            }
        }
    }
    
    if (shouldRotate) {
        return canRotate;
    } else {
        this->currentBlock->counterRotate();
        return shouldRotate;
    }
}

void Board::rotateBlockCounter(int times) {
    
    for (int i = 0; i < times; i++) {
        if (isCounterRotateValid()) {
            this->setBool();
        }
        else {
            this->setBool();
            break;
        }
    }
}

void Board::rotateBlockClock(int times) {
    for (int i = 0; i < times; i++) {
        if (isClockRotateValid()) {
            this->setBool();
        } else {
            this->setBool();
            break;
        }
    }
}

void Board::dropBlock() {
    this->moveBlockDown(17);
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->vectorCurrentBlock[i];
        this->board[get<1>(coord)][get<0>(coord)] = this->currentBlock;
    }
    
    this->setCurrentBlock(this->nextBlock);
    
    for (int i = 0; i < 4; i++) {
        std::tuple<int, int> coord = this->vectorCurrentBlock[i];
        if (this->board[get<1>(coord)][get<0>(coord)] != nullptr) {
            gameOver = true;
        }
    }
    
    shared_ptr<Block> ablock2 =
    make_shared<Block>(this->info, blockSelector(this->getInfo()->getLevel()));
    this->setNextBlock(ablock2);
    
    notify();
}

// Outputs block based on level and  probability according to
// requirements

char Board::blockSelector(int level) {
    
    char temp;
    int forLevel = level;
    bool tryAgain = true;
    
    if (forLevel == 1) {
        while (tryAgain) {
            
            int randomNUM = random() % 100;
            
            //Send out S Block
            if ((0 <= randomNUM) && (11 >= randomNUM)) {
                tryAgain = false;
                return 'S';
            }
            //Send out Z Block
            if ((12 <= randomNUM) && (23 >= randomNUM)) {
                tryAgain = false;
                return 'Z';
            }
            //Send out I Block
            if ((24 <= randomNUM) && (29 >= randomNUM)) {
                tryAgain = false;
                return 'I';
            }
            //Send out J Block
            if ((30 <= randomNUM) && (35 >= randomNUM)) {
                tryAgain = false;
                return 'J';
            }
            //Send out L Block
            if ((36 <= randomNUM) && (41 >= randomNUM)) {
                tryAgain = false;
                return 'L';
            }
            //Send out O Block
            if ((42 <= randomNUM) && (47 >= randomNUM)) {
                tryAgain = false;
                return 'O';
            }
            //Send out T Block
            if ((48 <= randomNUM) && (53 >= randomNUM)) {
                tryAgain = false;
                return 'T';
            }
        }
    } else if (forLevel == 2) {
        
        while (tryAgain) {
            
            int randomNUM = random() % 100;
            
            //Send out S Block
            if ((0 <= randomNUM) && (9 >= randomNUM)) {
                tryAgain = false;
                return 'S';
            }
            //Send out Z Block
            if ((10 <= randomNUM) && (19 >= randomNUM)) {
                tryAgain = false;
                return 'Z';
            }
            //Send out I Block
            if ((20 <= randomNUM) && (29 >= randomNUM)) {
                tryAgain = false;
                return 'I';
            }
            //Send out J Block
            if ((30 <= randomNUM) && (39 >= randomNUM)) {
                tryAgain = false;
                return 'J';
            }
            //Send out L Block
            if ((40 <= randomNUM) && (49 >= randomNUM)) {
                tryAgain = false;
                return 'L';
            }
            //Send out O Block
            if ((50 <= randomNUM) && (59 >= randomNUM)) {
                tryAgain = false;
                return 'O';
            }
            //Send out T Block
            if ((60 <= randomNUM) && (69 >= randomNUM)) {
                tryAgain = false;
                return 'T';
            }
        }
    } else if ((forLevel == 3) || (forLevel == 4)) {
        
        if (nonRandom) {
            
            string useFile = this->info->getNonRanFile();
            
            string block1;
            
            ifstream iFile;
            iFile.open(useFile);
            for (int i = 0; i < countReadNonRan; i++) {
                iFile >> block1;
            }
            
            iFile >> block1;
            countReadNonRan++;
            if (!iFile.eof()) {
                iFile.close();
                temp = block1[0];
                return temp;
                
            }  countReadNonRan = -1;
            blockSelector(level);
            
        }
        
        while (tryAgain) {
            
            int randomNUM = random() % 100;
            
            //Send out S Block
            if ((0 <= randomNUM) && (17 >= randomNUM)) {
                tryAgain = false;
                return 'S';
            }
            //Send out Z Block
            if ((18 <= randomNUM) && (35 >= randomNUM)) {
                tryAgain = false;
                return 'Z';
            }
            //Send out I Block
            if ((36 <= randomNUM) && (44 >= randomNUM)) {
                tryAgain = false;
                return 'I';
            }
            //Send out J Block
            if ((45 <= randomNUM) && (53 >= randomNUM)) {
                tryAgain = false;
                return 'J';
            }
            //Send out L Block
            if ((54 <= randomNUM) && (62 >= randomNUM)) {
                tryAgain = false;
                return 'L';
            }
            //Send out O Block
            if ((63 <= randomNUM) && (71 >= randomNUM)) {
                tryAgain = false;
                return 'O';
            }
            //Send out T Block
            if ((72 <= randomNUM) && (80 >= randomNUM)) {
                tryAgain = false;
                return 'T';
            }
        }
    } else {
        
        //Level is 0 and we should get input from file
        
        string useFile = this->info->getFileInUse();
        
        string block1;
        
        ifstream iFile;
        iFile.open(useFile);
        for (int i = 0; i < countRead; i++) {
            iFile >> block1;
        }
        
        iFile >> block1;
        countRead++;
        if (!iFile.eof()) {
            iFile.close();
            temp = block1[0];
            return temp;
            
        }  countRead = -1;
        blockSelector(level);
    }
    return blockSelector(level);
}

void Board::setStarBlock() {
    bool last = true;
    for (int i = 3; i < 18; i++) {
        if (this->getBoard()[i][5] != nullptr) {
            shared_ptr<Block> starBlock = make_shared<Block>(this->getInfo());
            this->board[i - 1][5] = starBlock;
            last = false;
            break;
        }
    }
    if (last){
        shared_ptr<Block> starBlock = make_shared<Block>(this->getInfo());
        this->board[17][5] = starBlock;
    }
}


