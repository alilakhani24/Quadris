//
//  block.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#ifndef block_h
#define block_h

#include <vector>
#include <tuple>
#include <map>
#include "information.h"

class Block {
protected:
    char type;
    std::vector<std::tuple<int, int>> config;
    Information *info;
    int levelCreated;
    bool heavy;

    // Sets the coordinates of the block based on block type
    std::vector<std::tuple<int, int>> setConfig();
    
public:
    // Creates the default "*" block used in level 4
    Block(Information *info);
    // Creates a block of type lType
    Block(Information *info, char lType);
    // Returns the type of the block
    char getType();
    // Returns the coordinates of the block
    std::vector<std::tuple<int, int>> getConfig();
    // Returns a pointer to the Information object in the block
    Information *getInfo();
    // Returns the level that the block was created
    int getLevelCreated();
    // Returns whether the block is heavy or not
    bool isHeavy();
    // Rotates the coordinates of the block 90 degrees clockwise
    void clockRotate();
    // Rotates the coordinates of the block 90 degrees counterclockwise
    void counterRotate();
};


#endif /* block_hpp */
