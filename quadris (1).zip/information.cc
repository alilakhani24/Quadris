//
//  information.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-16.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include "information.h"

void Information::setLevel(int x) {
    this->currentLevel = x;
}

void Information::setFileInUse(string file) {
    this->fileInUse = file;
}

void Information::Levelup() {
    this->currentLevel++;
}

void Information::Leveldown() {
    this->currentLevel--;
}

int Information::getLevel() {
    return this->currentLevel;
}

int Information::getScore() {
    return this->score;
}

int Information::getHighScore() {
    return this->highScore;
}

void Information::setLinesCleared(int lines) {
    this->linesJustCleared = lines;
}

int Information::getLinesCleared() {
    return this->linesJustCleared;
}

void Information::setScore(int aScore) {
    this->score = aScore;
}


string Information::getFileInUse() {
    return fileInUse;
}

int Information::getBlockGenLevel() {
    return blockGenLevel;
}

void Information::setBlockGenLevel(int lev) {
 ++lev;
}

void Information::setHighScore(int aScore) {
    this->highScore = aScore;
}

string Information::getNonRanFile() {
    return nonRanFile;
}
void Information::setNonRanFile(string str) {
    nonRanFile = str;
}

