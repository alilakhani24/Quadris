//
//  subject.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include "subject.h"
#include "observer.h"
using namespace std;

void Subject::addObserver(std::shared_ptr<Observer> observer) {
    observers.push_back(observer);
}

void Subject::notify() {
    for (auto &observer: observers)
        observer->notify(*this);
}

