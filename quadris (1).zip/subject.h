//
//  subject.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#ifndef subject_h
#define subject_h

#include <vector>
#include <memory>
#include "block.h"
#include "information.h"

class Observer;
class Subject {
    std::vector<std::shared_ptr<Observer>> observers;
    
public:
    // Adds an observer into the observers field
    void addObserver(std::shared_ptr<Observer> observer);
    // Notifies all observers in the observers fields of changes made to subject
    virtual void notify();
    // Gets the current representation of the board for displaying purposes
    virtual std::vector<std::vector<std::shared_ptr<Block>>> getBoard() = 0;
    // Gets the pointer to the current block on the board for displaying purposes
    virtual std::shared_ptr<Block> getCurrentBlock() = 0;
    // Gets the pointer to the next block that will be put on the board for displaying purposes
    virtual std::shared_ptr<Block> getNextBlock() = 0;
    // Gets the coordinates of the current block on the board for displaying purposes
    virtual std::vector<std::tuple<int, int>> vectorGetCurrentBlock() = 0;
    // Gets a pointer to the information object for displaying purposes
    virtual Information *getInfo() = 0;
};


#endif /* subject_hpp */
