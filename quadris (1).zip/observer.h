//
//  observer.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#ifndef observer_h
#define observer_h

class Subject;
class Board;
class Observer {
public:
    // Notifies subject about changes detected by the Observer
    virtual void notify(Subject &subject) = 0;
};

#endif /* observer_hpp */
