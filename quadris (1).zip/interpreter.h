//
//  interpreter.hpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-16.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#ifndef interpreter_h
#define interpreter_h

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include "information.h"
#include "board.h"
#include "block.h"
#include <memory>

using namespace std;

class Interpreter {
    
public:
    
    Information *info;
    Board *aboard;

    // Calls the moveLeft method
    // the number of times entered
    void left(int times);
    // Calls the moveRight method
    // the number of times entered
    void right(int times);
    // Calls the moveDown method
    // the number of times entered
    void down(int times);
    // Calls the moveClockwise method
    // the number of times entered
    void clockwise(int times);
    // Calls the moveCounter Clockwise method
    // the number of times entered
    void counterclockwise(int times);
    // Calls the Drop method
    void drop();
    // Calls the levelup method
    void levelup();
    // Calls the leveldown method
    void leveldown();
    // Makes game state random in level 3/4
    void random();
    // Makes game state nonrandom and reads from
    // given file
    void norandom(string name);
    // Restarts game keeping track of current level
    // and highscore
    void restart();
    // Displays a hint
    void hint();
    // Reads from a sequence file inputed by user
    void sequence(string name);
    
    // Sets the called  block as the current block
    void I();
    void J();
    void L();
    void O();
    void S();
    void Z();
    void T();
    
    
    // will be used to run commands on referenced board)
    void run(istream &in);
    // Initializes interpreter with given info and board class
    Interpreter(Information *info, Board *aBoard);
    
};




#endif /* interpreter_hpp */
