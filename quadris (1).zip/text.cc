//
//  text.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include <memory>
#include <vector>
#include <tuple>
#include <string>
#include "text.h"
#include "block.h"
#include "information.h"
#include "subject.h"
using namespace std;

// Used to print the header of the text display justified to the right
void justify(string s, int i) {
    int spaces = 12;
    spaces -= s.length();
    for (int x = i; x % 10 > 10; x /= 10) --spaces;
    cout << s;
    for (int x = 0; x < spaces; ++x) cout << " ";
    cout << i << endl;
}

void Text::notify(Subject &subject) {
    vector<vector<shared_ptr<Block>>> aBoard = subject.getBoard();
    Information *info = subject.getInfo();
    shared_ptr<Block> currentBlock = subject.getCurrentBlock();
    shared_ptr<Block> nextBlock = subject.getNextBlock();
    vector<tuple<int, int>> vectorCurrentBlock = subject.vectorGetCurrentBlock();
    
    int height = aBoard.size();
    int length = aBoard[0].size();
    
    vector<vector<char>> holdPrint;
    for (int y = 0; y < height; ++y) {
        vector<char> holder;
        for (int x = 0; x < length; ++x) {
            if (aBoard[y][x] == nullptr) holder.push_back(' ');
            else holder.push_back(aBoard[y][x]->getType());
        }
        holdPrint.push_back(holder);
    }
    for (auto &coordinate: vectorCurrentBlock)
        holdPrint[get<1>(coordinate)][get<0>(coordinate)] = currentBlock->getType();
    
    justify("Level:", info->getLevel());
    justify("Score:", info->getScore());
    justify("Hi Score:", info->getHighScore());
    cout << "-------------" << endl;
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < length; ++x)
            cout << holdPrint[y][x];
        cout << endl;
    }
    cout << "-------------" << endl << "Next:" << endl;
    
    vector<vector<char>> nextBlockPrint;
    for (int y = 0; y < 4; ++y) {
        vector<char> holder2;
        for (int x = 0; x < 4; ++x)
            holder2.push_back(' ');
        nextBlockPrint.push_back(holder2);
    }
    for (auto &coordinate: nextBlock->getConfig())
        nextBlockPrint[get<1>(coordinate)][get<0>(coordinate)] = nextBlock->getType();
    bool empty = false;
    for (int y = 0; y < 4; ++y) {
        for (int x = 0; x < 4; ++x) {
            if (x == 0 && nextBlockPrint[y][0] == ' ' && nextBlockPrint[y][1] == ' ' && nextBlockPrint[y][2] == ' ' && nextBlockPrint[y][3] == ' ') {
                empty = true;
                break;
            }
            cout << nextBlockPrint[y][x];
        }
        if (!empty) cout << endl;
        empty = false;
    }
}

