//
//  block.cpp
//  finalProject
//
//  Created by Ali Lakhani on 2018-07-19.
//  Copyright © 2018 Ali Lakhani. All rights reserved.
//

#include <vector>
#include <tuple>
#include <map>
#include "block.h"
using namespace std;

Block::Block(Information *info) {
    type = '*';
    config.push_back(tuple<int, int>(0, 0));
    info = info;
    levelCreated = info->getLevel();
    if (levelCreated <= 2) heavy = false;
    else heavy = true;
}

Block::Block(Information *info, char lType) {
    type = lType;
    config = setConfig();
    info = info;
    levelCreated = info->getLevel();
    if (levelCreated <= 2) heavy = false;
    else heavy = true;
}

char Block::getType() {
    return type;
}

vector<tuple<int, int>> Block::getConfig() {
    return config;
}

Information *Block::getInfo() {
    return info;
}

int Block::getLevelCreated() {
    return levelCreated;
}

bool Block::isHeavy() {
    return heavy;
}

vector<tuple<int, int>> Block::setConfig() {
    vector<tuple<int, int>> rConfig;
    
    if (type == 'I' || type == 'i') {
        rConfig.push_back(tuple<int, int>(0, 0));
        rConfig.push_back(tuple<int, int>(1, 0));
        rConfig.push_back(tuple<int, int>(2, 0));
        rConfig.push_back(tuple<int, int>(3, 0));
    } else if (type == 'J' || type == 'j') {
        rConfig.push_back(tuple<int, int>(0, 0));
        rConfig.push_back(tuple<int, int>(0, 1));
        rConfig.push_back(tuple<int, int>(1, 1));
        rConfig.push_back(tuple<int, int>(2, 1));
    } else if (type == 'L' || type == 'l') {
        rConfig.push_back(tuple<int, int>(2, 0));
        rConfig.push_back(tuple<int, int>(0, 1));
        rConfig.push_back(tuple<int, int>(1, 1));
        rConfig.push_back(tuple<int, int>(2, 1));
    } else if (type == 'O' || type == 'o') {
        rConfig.push_back(tuple<int, int>(0, 0));
        rConfig.push_back(tuple<int, int>(1, 0));
        rConfig.push_back(tuple<int, int>(0, 1));
        rConfig.push_back(tuple<int, int>(1, 1));
    } else if (type == 'S' || type == 's') {
        rConfig.push_back(tuple<int, int>(1, 0));
        rConfig.push_back(tuple<int, int>(2, 0));
        rConfig.push_back(tuple<int, int>(0, 1));
        rConfig.push_back(tuple<int, int>(1, 1));
    } else if (type == 'Z' || type == 'z') {
        rConfig.push_back(tuple<int, int>(0, 0));
        rConfig.push_back(tuple<int, int>(1, 0));
        rConfig.push_back(tuple<int, int>(1, 1));
        rConfig.push_back(tuple<int, int>(2, 1));
    } else {
        rConfig.push_back(tuple<int, int>(0, 0));
        rConfig.push_back(tuple<int, int>(1, 0));
        rConfig.push_back(tuple<int, int>(2, 0));
        rConfig.push_back(tuple<int, int>(1, 1));
    }
    return rConfig;
}

void Block::counterRotate() {
    vector<tuple<int, int>> newConfig = getConfig();
    int minX = 0, minY = 0;
    
    for (auto &coordinate : newConfig) {
        coordinate = tuple<int, int> (get<1>(coordinate), get<0>(coordinate) * -1);
        if (get<0>(coordinate) < minX) minX = get<0>(coordinate);
        if (get<1>(coordinate) < minY) minY = get<1>(coordinate);
    }
    for (auto &coordinate : newConfig)
        coordinate = tuple<int, int> (get<0>(coordinate) - minX, get<1>(coordinate) - minY);
    config = newConfig;
}

void Block::clockRotate() {
    vector<tuple<int, int>> newConfig = getConfig();
    int minX = 0, minY = 0;
    
    for (auto &coordinate : newConfig) {
        coordinate = tuple<int, int> (get<1>(coordinate) * -1, get<0>(coordinate));
        if (get<0>(coordinate) < minX) minX = get<0>(coordinate);
        if (get<1>(coordinate) < minY) minY = get<1>(coordinate);
    }
    for (auto &coordinate : newConfig)
        coordinate = tuple<int, int> (get<0>(coordinate) - minX, get<1>(coordinate) - minY);
    config = newConfig;
}
